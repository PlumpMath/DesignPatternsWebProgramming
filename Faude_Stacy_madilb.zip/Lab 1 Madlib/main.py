print ("This is Stacy's Mad Lib Game")

response1 = raw_input("Do you prefer Morning Noon or Night ")

response2 = raw_input("Enter a number ")

response3 = raw_input("Was it something I said or something I did?")

response4 = raw_input("Did my words not come out right? yes or no")

print "We both lie silently still in the dead of the " + response1

print "Although we both lie close together we feel " + response2 + " miles apart inside"

'''
if response3 = said:
    print "It was something I said"
elif response3 = did:
    print "It was something I did"

print response4

'''